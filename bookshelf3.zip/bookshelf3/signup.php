<?php
session_start();
if(isset($_SESSION['erreur_user']))
{
    $erreur_user = $_SESSION['erreur_user'];
    unset($_SESSION['erreur_user']);
}
if(isset($_SESSION['user']))
{
	$user = $_SESSION['user'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign up — Bookshelf</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- ============== Navbar ============== -->
  <nav class="navbar">
    <div class="nav-inner">
      <a href="index.php" class="logo">
        <span class="accent">B</span>ook<span class="accent">s</span>helf
      </a>
      <button class="menu-btn" aria-label="open menu"><i class="fa-solid fa-bars"></i></button>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <?php if (!empty($user)): ?>
        <li><a href="buy.php" >Buy</a></li>
        <li><a href="sell.php">Sell</a></li>
        <?php endif; ?>
        <?php if (empty($user)): ?>
        <li><a href="login.php">Login</a></li>
        <li><a href="signup.php">Sign up</a></li>
        <?php endif; ?>
        <?php if (!empty($user)): ?>
        <?php echo $user; ?>
        <li><a href="logout.php">Logout</a></li>
        <a href="cart.php" class="cart-link" aria-label="cart">
            <i class="fa-solid fa-cart-shopping"></i>
            <span class="cart-count">0</span>
          </a>
        </li>
        <?php endif; ?>
        </li>
      </ul>
    </div>
  </nav>

  <main>
    <section class="auth-wrap">
      <!-- Sign-up form -->
      <div class="auth-card">
        <h2>Create your account</h2>
        <p class="subtitle">Join Bookshelf and start sharing your books.</p>

        <!-- TODO_BACKEND : action="/signup.php" method="POST" -->
        <form id="signup-form" novalidate action="verif.php" method="POST">

          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" class="form-control"
                   placeholder="Amira B." required>
            <div class="form-error" data-error="name"></div>
          </div>

          <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" class="form-control"
                   placeholder="you@example.com" required>
            <div class="form-error" data-error="email"></div>
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" class="form-control"
                   placeholder="at least 6 characters" required>
            <div class="form-error" data-error="password"></div>
          </div>

          <div class="form-group">
            <label for="confirm">Confirm password</label>
            <input type="password" id="confirm" name="confirm" class="form-control"
                   placeholder="repeat your password" required>
            <div class="form-error" data-error="confirm"></div>
          </div>

          <button type="submit" class="btn btn-block">Sign up</button>
        <?php if (!empty($erreur_user)): ?>
	    <div class="alert alert-danger mt-2 text-center"><?= $erreur_user; ?></div>
	    <?php endif; ?>
        </form>

        <p class="auth-switch">
          Already have an account ? <a href="login.php">Log in</a>
        </p>
      </div>
    </section>
  </main>

  <script src="script.js"></script>
</body>
</html>
