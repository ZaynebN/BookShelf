<?php
session_start();
require_once "connect.php";
if($_SERVER["REQUEST_METHOD"] === "POST")
{
	$name = htmlspecialchars(trim($_POST['name']));
	$password = htmlspecialchars(trim($_POST['password']));
    $email = htmlspecialchars(trim($_POST['email']));
	$pwdhash = hash("sha256", $password);
	$req = "SELECT id FROM users WHERE name ='$name' AND password = '$pwdhash'";
	
	$res= mysqli_query($conn , $req);
	if(!$res)
	{
		echo "erreeur";
	}
	if(mysqli_num_rows($res)==1)
	{
		$_SESSION['erreur_user'] = '<strong>User Exists</strong>';
		header("location:signup.php");
		exit;
	}
	

$req = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$pwdhash')";
$res= mysqli_query($conn , $req);
if(!$res)
{
	echo "erreeur insertion";
}
header("location:login.php");
}
?>
