<?php
session_start();
if(isset($_SESSION['user']))
{
	$user = $_SESSION['user'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bookshelf — Buy & Sell Used Books</title>
  <meta name="description" content="A vintage marketplace for second-hand books — give every book a second life.">
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- ============== Navbar ============== -->
  <nav class="navbar">
    <div class="nav-inner">
      <a href="index.php" class="logo">
        <span class="accent">B</span>ook<span class="accent">s</span>helf
      </a>
      <button class="menu-btn" aria-label="open menu"><i class="fa-solid fa-bars"></i></button>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <?php if (!empty($user)): ?>
        <li><a href="buy.php" >Buy</a></li>
        <li><a href="sell.php">Sell</a></li>
        <?php endif; ?>
        <?php if (empty($user)): ?>
        <li><a href="login.php">Login</a></li>
        <li><a href="signup.php">Sign up</a></li>
        <?php endif; ?>
        <?php if (!empty($user)): ?>
        <?php echo $user; ?>
        <li><a href="logout.php">Logout</a></li>
        <a href="cart.php" class="cart-link" aria-label="cart">
            <i class="fa-solid fa-cart-shopping"></i>
            <span class="cart-count">0</span>
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </nav>

  <main>

    <!-- ============== Hero ============== -->
    <header class="hero">
      <div class="hero-content">
        <h1>Give every book <span>a second life</span></h1>
        <p>
          Bookshelf is a quiet little marketplace where readers buy and sell
          their pre-loved books. Browse the catalog, list the volumes that
          have already taught you what they could, and make room on your shelf
          for the next adventure.
        </p>
        <div class="hero-buttons">
          <a href="buy.php"  class="btn btn-light">Browse Books</a>
          <a href="sell.php" class="btn btn-outline" style="background:rgba(0,0,0,.15); color:var(--cream); border-color:var(--cream);">Sell a Book</a>
        </div>
      </div>
    </header>

    <!-- ============== Quote band ============== -->
    <section class="quote-band">
      <p>“A room without books is like a body without a soul.”</p>
      <span>— Marcus Tullius Cicero</span>
    </section>

    <!-- ============== How it works ============== -->
    <section class="section">
      <div class="section-title">
        <h2>How Bookshelf works</h2>
        <p>Three simple steps — no clutter, just books.</p>
        </div>

        <div class="how-grid">
          <article class="how-card">
            <div class="icon"><i class="fa-solid fa-user-plus"></i></div>
            <h3>Create an account</h3>
            <p>Sign up in less than a minute and join a community of readers who care about books.</p>
          </article>
          <article class="how-card">
            <div class="icon"><i class="fa-solid fa-book"></i></div>
            <h3>List your books</h3>
            <p>Add a cover, a title, the author, the genre and the condition — your book is now visible to everyone.</p>
          </article>
          <article class="how-card">
            <div class="icon"><i class="fa-solid fa-magnifying-glass"></i></div>
            <h3>Find your next read</h3>
            <p>Search the catalog by title, filter by genre or by length, add to cart, and check out.</p>
          </article>
          <article class="how-card">
            <div class="icon"><i class="fa-solid fa-leaf"></i></div>
            <h3>Read sustainably</h3>
            <p>Each second-hand book bought is one tree saved and one story passed on.</p>
          </article>
        </div>
      </section>

      <!-- ============== Call to action ============== -->
      <section class="quote-band" style="background:var(--brown-deep); color:var(--cream); border:none;">
        <p style="color:var(--brown-light)">Ready to make space on your shelf ?</p>
        <span style="color:var(--beige)">Start selling in a few clicks.</span>
        <div style="margin-top:1.5rem">
          <a href="signup.php" class="btn btn-light">Create my account</a>
        </div>
      </section>

    </main>

    <!-- ============== Footer ============== -->
    <footer>
      <div class="footer-inner">
        <div class="footer-col">
          <h4><span style="color:var(--brown-light)">B</span>ook<span style="color:var(--brown-light)">s</span>helf</h4>
          <p>A small, independent marketplace for second-hand books — built for readers, by readers.</p>
          <div class="socials">
            <a href="#" aria-label="facebook"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#" aria-label="twitter"><i class="fa-brands fa-twitter"></i></a>
            <a href="#" aria-label="instagram"><i class="fa-brands fa-instagram"></i></a>
          </div>
        </div>
        <div class="footer-col">
          <h4>Explore</h4>
          <ul>
            <li><a href="buy.php">Buy books</a></li>
            <li><a href="sell.php">Sell books</a></li>
            <li><a href="cart.php">My cart</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Account</h4>
          <ul>
            <li><a href="login.php">Login</a></li>
            <li><a href="signup.php">Sign up</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Contact</h4>
          <p><i class="fa-solid fa-envelope"></i> &nbsp; contact@bookshelf.local</p>
          <p><i class="fa-solid fa-phone"></i> &nbsp; +216 71 000 000</p>
        </div>
      </div>
      <div class="copyright">© 2026 Bookshelf — All rights reserved.</div>
    </footer>

    <script src="script.js"></script>
  </body>
  </html>
