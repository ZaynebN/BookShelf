<?php
session_start();
require_once "connect.php";
if($_SERVER["REQUEST_METHOD"] === "POST")
{
	$email = htmlspecialchars(trim($_POST['email']));
	$password = htmlspecialchars(trim($_POST['password']));
	$pwdhash = hash("sha256", $password);
	$req = "select name from users where email ='$email'
	and password = '$pwdhash'";
	
	$res= mysqli_query($conn , $req);
	if(!$res)
	{
		echo "erreeur connexion";
	}
	if(mysqli_num_rows($res)==0)
	{
		$_SESSION['info'] = '<strong>Code(s) d\'accès invalide(s)</strong>';
		header("location:login.php");
		exit;
    }
	
$data = mysqli_fetch_array($res); 
$_SESSION['user'] = $data['name'];
header("location:index.php");
}
?>