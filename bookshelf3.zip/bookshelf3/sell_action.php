<?php
session_start();
require_once "connect.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // ===== check user =====
    if(!isset($_SESSION['user'])) {
        header("Location: login.php");
        exit;
    }

    // ===== get user id =====
    $username = $_SESSION['user'];
    $u = "SELECT id FROM users WHERE name = '$username'";
    $res_user = mysqli_query($conn, $u);
    $user_data = mysqli_fetch_assoc($res_user);
    $user_id = $user_data['id'];

    // ===== get form data =====
    $title   = htmlspecialchars(trim($_POST['title']));
    $author  = htmlspecialchars(trim($_POST['author']));
    $pages   = $_POST['pages'];
    $quality = $_POST['quality'];
    $price   = $_POST['price'];
    $info    = htmlspecialchars(trim($_POST['info']));
    $cover   = $_POST['cover'];

    // ===== insert book =====
    $req = "INSERT INTO books (user_id, title, author, cover, pages, quality, price, info)
            VALUES ('$user_id', '$title', '$author', '$cover', '$pages', '$quality', '$price', '$info')";

    $res = mysqli_query($conn, $req);

    if(!$res) {
        echo "Error inserting book";
        exit;
    }

    // ===== get book id =====
    $book_id = mysqli_insert_id($conn);

    // ===== insert genres =====
    if(isset($_POST['genre'])) {

        foreach($_POST['genre'] as $genre_name) {

            $g = "SELECT id FROM genre WHERE name = '$genre_name'";
            $result = mysqli_query($conn, $g);

            if($row = mysqli_fetch_assoc($result)) {
                $genre_id = $row['id'];

                mysqli_query($conn, " INSERT INTO book_genre (book_id, genre_id)
                VALUES ('$book_id', '$genre_id') ");
            }
        }
    }

    header("Location: index.php");
    exit;
}
?>