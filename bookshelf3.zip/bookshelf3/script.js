/* ── cart count in navbar ── */
function updateCartCount() {
  const el = document.querySelector('.cart-count');
  if (el) el.textContent = JSON.parse(localStorage.getItem('cart') || '[]').length;
}

/* ── mobile menu ── */
const menuBtn = document.querySelector('.menu-btn');
const navLinks = document.querySelector('.nav-links');
if (menuBtn) menuBtn.onclick = () => navLinks.classList.toggle('open');

/* ── active nav link ── */
const page = location.pathname.split('/').pop() || 'index.php';
document.querySelectorAll('.nav-links a').forEach(a => {
  if (a.getAttribute('href') === page) a.classList.add('active');
});

/* ── SIGNUP form validation ── */
const signupForm = document.getElementById('signup-form');
if (signupForm) {
  signupForm.onsubmit = function(e) {
    const name     = signupForm.name.value.trim();
    const email    = signupForm.email.value.trim();
    const password = signupForm.password.value;
    const confirm  = signupForm.confirm.value;

    if (name.length < 2) {
      e.preventDefault();
      alert('Name must be at least 2 characters.');
      return;
    }
    if (!email.includes('@') || !email.includes('.')) {
      e.preventDefault();
      alert('Please enter a valid e-mail address.');
      return;
    }
    if (password.length < 6) {
      e.preventDefault();
      alert('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirm) {
      e.preventDefault();
      alert('Passwords do not match.');
      return;
    }
    // all good — form submits to verif.php
  };
}

/* ── LOGIN form validation ── */
const loginForm = document.getElementById('login-form');
if (loginForm) {
  loginForm.onsubmit = function(e) {
    const email    = loginForm.email.value.trim();
    const password = loginForm.password.value;

    if (!email.includes('@') || !email.includes('.')) {
      e.preventDefault();
      alert('Please enter a valid e-mail address.');
      return;
    }
    if (password.length < 6) {
      e.preventDefault();
      alert('Password must be at least 6 characters.');
      return;
    }
    // all good — form submits to traitement.php
  };
}

/* ── SELL form validation ── */
const sellForm = document.getElementById('sell-form');
if (sellForm) {
  // show selected filename
  const fileInput = document.querySelector('input[type=file]');
  const fileLabel = document.querySelector('.file-name');
  if (fileInput && fileLabel) {
    fileInput.onchange = () => fileLabel.textContent = fileInput.files[0]?.name || 'no file chosen';
  }

  sellForm.onsubmit = function(e) {
    const title   = sellForm.title.value.trim();
    const author  = sellForm.author.value.trim();
    const pages   = sellForm.pages.value;
    const quality = sellForm.quality.value;
    const price   = parseFloat(sellForm.price.value);
    const genres  = [...sellForm.querySelectorAll('input[name=genre]:checked')];

    if (!title) {
      e.preventDefault();
      alert('Please enter the book title.');
      return;
    }
    if (!author) {
      e.preventDefault();
      alert('Please enter the author name.');
      return;
    }
    if (fileInput && !fileInput.files[0]) {
      e.preventDefault();
      alert('Please upload a cover image.');
      return;
    }
    if (!pages) {
      e.preventDefault();
      alert('Please choose a page range.');
      return;
    }
    if (genres.length === 0) {
      e.preventDefault();
      alert('Please pick at least one genre.');
      return;
    }
    if (!quality) {
      e.preventDefault();
      alert('Please choose a quality.');
      return;
    }
    if (isNaN(price) || price < 0.5) {
      e.preventDefault();
      alert('Please enter a valid price (min $0.50).');
      return;
    }
    // all good — form submits to sell.php
  };
}

updateCartCount();