<?php
session_start();
if(isset($_SESSION['user']))
{
	$user = $_SESSION['user'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Buy Books — Bookshelf</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- ============== Navbar ============== -->
  <nav class="navbar">
    <div class="nav-inner">
      <a href="index.php" class="logo">
        <span class="accent">B</span>ook<span class="accent">s</span>helf
      </a>
      <button class="menu-btn" aria-label="open menu"><i class="fa-solid fa-bars"></i></button>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <?php if (!empty($user)): ?>
        <li><a href="buy.php" >Buy</a></li>
        <li><a href="sell.php">Sell</a></li>
        <?php endif; ?>
        <?php if (empty($user)): ?>
        <li><a href="login.php">Login</a></li>
        <li><a href="signup.php">Sign up</a></li>
        <?php endif; ?>
        <?php if (!empty($user)): ?>
        <?php echo $user; ?>
        <li><a href="logout.php">Logout</a></li>
        <a href="cart.php" class="cart-link" aria-label="cart">
            <i class="fa-solid fa-cart-shopping"></i>
            <span class="cart-count">0</span>
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </nav>

  <main>
    <section class="section">

      <div class="section-title">
        <h2>Browse the catalog</h2>
        <p>Find your next favourite — already loved by another reader.</p>
      </div>

      <div class="catalog-wrap">

        <!-- ====== filters ====== -->
        <aside class="filters">

          <div class="filter-group">
            <h4>Genre</h4>
            <div class="filter-btns">
              <button class="active">All genres</button>
              <label>
                <input type="checkbox" name="fiction">
                Fiction
              </label>
              <label>
                <input type="checkbox" name="non_fiction">
                Non-fiction
              </label>
              <label>
                <input type="checkbox" name="classics">
                Classics
              </label>
              <label>
                <input type="checkbox" name="philosophy">
                Philosophy
              </label>
              <label>
                <input type="checkbox" name="science">
                Science
              </label>
              <label>
                <input type="checkbox" name="history">
                History
              </label>
              <label>
                <input type="checkbox" name="romance">
                Romance
              </label>
              <label>
                <input type="checkbox" name="children">
                Children
              </label>
              <label>
                <input type="checkbox" name="art">
                Art
              </label>
            </div>
          </div>
          <div class="filter-group">
            <h4>Pages</h4>
            <select class="form-control">
              <option value="All">Any length</option>
              <option value="0-100">0 – 100 pages</option>
              <option value="100-200">100 – 200 pages</option>
              <option value="200-300">200 – 300 pages</option>
              <option value="300-400">300 – 400 pages</option>
              <option value="400+">More than 400 pages</option>
            </select>
          </div>
            <a href="search.php" class="btn">Search</a>
        </aside>

        <!-- ====== catalog ====== -->
        <div>
          <div class="search-bar">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="search" placeholder="search by title…">
          </div>

          <div class="book-wrap">
          </div>
        </div>

      </div>
    </section>
  </main>

  <script src="script.js"></script>
</body>
</html>